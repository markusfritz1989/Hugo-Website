---
title: "About us"
date: 2019-12-05T12:24:03+01:00
draft: true
---

Hi, this is us! We, Linda and Markus, hop you enjoy our little static Website!

# Linda Feichtner

![CMS](http://localhost:1313/images/lindafeichtner.jpg)

# Markus Fritz

![CMS](http://localhost:1313/images/markusfritz.jpg)



