---
title: "Question Nr. 1"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# Difference between static and dynamic websites?

One of the main difference of a static website compared to a dynamic website is that the static web page display the same content each time when someone visits it, whereas in the case of the dynamic web page, the page content changes according to the user. Static websites are those which will remain the same until someone changes it manually, butit’s content doesn’t change regularly. Dynamic web pages on the other hand are behavioral and are able to produce distinctive content for different visitors. In a static web page there is no database used – in distinction form a dynamic web page. 

A static website refers to a website that is served to the client in the form of static HTML files. When the user visits a certain page, the corresponding HTML file is then sent back to be displayed by the browser. A dynamic website on the other hand is created dynamically. The result is the same HTML code, but there is much more work required by the server (gathering data, generating HTML, etc.) – every time a user visits the site.

## If you are interested in further details, we've provided a video for you! Just click on it and enjoy!

[![Static vs Dynamic](http://localhost:1313/images/staticvsdynamic.png)](https://www.youtube.com/watch?v=hlg6q6OFoxQ "Static vs dynamic")



