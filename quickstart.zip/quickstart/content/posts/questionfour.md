---
title: "Question Nr. 4"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# How does it defer from a 'classical' CMS?

In comparison to ‘classical’ CMS, it’s much easier for people who don’t have any experience with HTML, etc. to create their own website, as you need rarely any knowledge do that with SWG. Concerning the storage, static website generators store all the data locally on the user’s server and do not access data from different databases or other external data sources (like CMS does).



