---
title: "Question Nr. 2"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# What is a Content Management System (CMS)?

A Content Management System is a software application or a set of programs used to create and manage content for websites (and other digital content) without needing to write all the code. The CMS handles all the basic infrastructure for building the web page. Its main job is to put together all the data from different databases (pictures, videos, structured text, etc.), fill the gaps with templates and in the end to provide output for the browser to show (in form of HTML).


![CMS](http://localhost:1313/images/cms.jpg)



