---
title: "Question Nr. 7"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# Use cases for Static Website Generators?

There are a lot of cases, where you can use Static Website Generators. What they all have in common is – of course – that they are rarely (if ever updated). Use Cases include personal websites or portfolios, where you present your CV and employers’ references in order to apply for a new job, landing pages, online books, presentations, documentation sites and so on. 




