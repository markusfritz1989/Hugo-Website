---
title: "Question Nr. 5"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# Benefits vs. Drawbacks of Static Website Generators?

One of the biggest benefits is of course that static websites are easy in the development, they are cheap and fast to set up. Website creators don’t need experience or advanced knowledge in web development. In addition, static websites are scalable, secure and extremely fast (since there are no database queries, no client-server requests, etc.).
A big disadvantage of static websites is that the website owner is restricted by the themes and that he/she has much less functions than in classical CMS. Moreover, websites created with the same generator may look the same (if the same theme is used) and therefore the website isn’t individual. Additionally, considering the SEO aspect, static website generators don’t have that many options to optimize SEOwise in order to rank high. Another drawback of these websites is that there are constraints in the user interaction as well. 




