---
title: "Question Nr. 6"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# How does a typical Static Website Generator (e.g. Hugo) work?

Content creation is done via simple markup with no need for the website owner to deal with  HTML or CSS. Content and style(s) are clearly separated and the generator supports in creating well structured (textual) content. Website operator should be enabled to primarily focus on the content. The site design can be done separately.

## 1.6.1 What type of input data is being used?
What you have to put in are template(s), styles, content (in the form of markdown, etc.) and the configuration in a way.  

## 1.6.2 What type of output data is being generated?
What you get is in fact the same what you get from a CMS: HTML, CSS and Scripts.




