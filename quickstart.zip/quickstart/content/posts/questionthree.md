---
title: "Question Nr. 3"
date: 2019-12-05T12:24:03+01:00
draft: true
---

# What is a Static Website Generator, how does it fit into the systemic view derived from questions 1.1 and 1.2?

A Static Website Generator is a tool or an item, which helps building websites with little or no changes. In short: As the name says - it helps to create static websites. It enables users, which are not really into coding, to create their own website without any professional help. 




