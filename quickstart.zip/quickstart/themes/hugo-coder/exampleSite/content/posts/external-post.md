+++
date = "2019-01-17"
title = "Hugo coder wiki"
slug = "hugo-coder-wiki"
tags = [
    "hugo",
    "development",
    "themes"
]
categories = [
    "Development",
]
externalLink = "https://github.com/luizdepra/hugo-coder/wiki"
series = ["Hugo"]
+++
